function showDrinks(){

}

function addTocart(){
    
}