// global
var products=[];
var cartItems = [];
var cart_n = document.getElementById('cart_n') ; 
// var cart_n=[]

// DIV
var fruitDIV = document.getElementById ("fruitDIV");
var juiceDIV = document.getElementById ("juiceDIV");
var saladDIV = document.getElementById ("saladDIV") ;
 // info
 
 var FRUIT = [
     
 {name: 'Apple',price: 1},
  {name: 'Apple' ,price: 1},
  {name: 'Apple' ,price: 1},
  {name: 'Apple' ,price: 1},

  {name: 'Apple' ,price: 1},
  {name: 'Apple' ,price: 1},
  {name: 'Apple' ,price: 1}
  

];

var JUICE=[
    {name:"juice#1",price:10},
    {name:"juice#2",price:10},
    {name:"juice#3",price:10}

]
var SALAD=[
    {name:"Salad #1",price:11},
    {name:"Salad #1",price:11},
    {name:"Salad #1",price:11}

]

// HTML

function HTMLfruitProduct(con){
    let URL=`img/fruits/fruit${con}.jpg`;
    let btn= `btnFruits${con}`;
    return `
    <div class="col-md-4">
    <div class ="card mb-4 shadow-sm">
    <img class= "card-img-top" style="height:16rem;" src="${URL}"
    alt="Card image cap">

    <div class="card-body">
    <i style="color:orange;" class="fa fa-star"></i>
    <i style="color:orange;" class="fa fa-star"></i>
    <i style="color:orange;" class="fa fa-star"></i>
    <i style="color:orange;" class="fa fa-star"></i>
    <i style="color:orange;" class="fa fa-star"></i>
    <p clas="card-text">${FRUIT[con-1].name}</p>
    <p clas="card-text">${FRUIT[con-1].price}.00</p>
    <div class="d-flex justify-content-between align-item-center">

    <div class="btn-group"   >

    <button type="button" onclick="cart2('${FRUIT[con-1].name}','${FRUIT[con-1].price}','${URL}','${con}',
    '${btn}')" class="btn btn-sm btn-outline-secondary" > <a href="cart.html" style="color:inherit;" > Buy</a>    </button>

    <button id="${btn}" type="button" onclick="cart('${FRUIT[con-1].name}','${FRUIT[con-1].price}','${URL}','${con}',
    '${btn}')" class="btn btn-sm btn-outline-secondary" >add to cart   </button>
      </div>

        <small class="text-muted">free Shiping </small>

    </div>

    </div>

    </div>
    </div>
    `
}

// -----------------------------------------------


function HTMLjuiceProduct(con){
    let URL=`img/fruits/fruit${con}.jpg`;
    let btn= `btnJuice${con}`;
    return `
    <div class="col-md-4">
    <div class ="card mb-4 shadow-sm">
    <img class= "card-img-top" style="height:16rem;" src="${URL}"
    alt="Card image cap">

    <div class="card-body">
    <i style="color:orange;" class="fa fa-star"></i>
    <i style="color:orange;" class="fa fa-star"></i>
    <i style="color:orange;" class="fa fa-star"></i>
    <i style="color:orange;" class="fa fa-star"></i>
    <i style="color:orange;" class="fa fa-star"></i>
    <p clas="card-text">${JUICE[con-1].name}</p>
    <p clas="card-text">${JUICE[con-1].price}.00</p>
    <div class="d-flex justify-content-between align-item-center">

    <div class="btn-group"   >

    <button type="button" onclick="cart2('${JUICE[con-1].name}','${JUICE[con-1].price}','${URL}','${con}',
    '${btn}')" class="btn btn-sm btn-outline-secondary" > <a href="cart.html" style="color:inherit;" > Buy</a>    </button>

    <button id="${btn}" type="button" onclick="cart('${JUICE[con-1].name}','${JUICE[con-1].price}','${URL}','${con}',
    '${btn}')" class="btn btn-sm btn-outline-secondary" >add to cart   </button>
      </div>

        <small class="text-muted">free Shiping </small>

    </div>

    </div>

    </div>
    </div>
    `
}

// -----------------------------------------------


function HTMLsaladProduct(con){
    let URL=`img/fruits/fruit${con}.jpg`;
    let btn= `btnSalad${con}`;
    return `
    <div class="col-md-4">
    <div class ="card mb-4 shadow-sm">
    <img class= "card-img-top" style="height:16rem;" src="${URL}"
    alt="Card image cap">

    <div class="card-body">
    <i style="color:orange;" class="fa fa-star"></i>
    <i style="color:orange;" class="fa fa-star"></i>
    <i style="color:orange;" class="fa fa-star"></i>
    <i style="color:orange;" class="fa fa-star"></i>
    <i style="color:orange;" class="fa fa-star"></i>
    <p clas="card-text">${SALAD[con-1].name}</p>
    <p clas="card-text">${SALAD[con-1].price}.00</p>
    <div class="d-flex justify-content-between align-item-center">

    <div class="btn-group"   >

    <button type="button" onclick="cart2('${SALAD[con-1].name}','${SALAD[con-1].price}','${URL}','${con}',
    '${btn}')" class="btn btn-sm btn-outline-secondary" > <a href="cart.html" style="color:inherit;" > Buy</a>   </button>

    <button id="${btn}" type="button" onclick="cart('${SALAD[con-1].name}','${SALAD[con-1].price}','${URL}','${con}',
    '${btn}')" class="btn btn-sm btn-outline-secondary" >add to cart   </button>
      </div>

        <small class="text-muted">free Shiping </small>

    </div>

    </div>

    </div>
    </div>
    `
}
// -------------------------------------------------------------

function animation(){
    swal.mixin({
        position:"top-end",
        showConfirmButton:false,
        timer:1000,
        type:'success',
        title:"added to shoping cart"
    });
   
}


// ----------------------------------------------

function cart(name,price,URL,con,btncart){
    var item={
        name:name,
        price:price,
        URL:URL
    }
    cartItems.push(item);
    let storage=JSON.parse(localStorage.getItem("cart"));
    if(storage==null){
        products.push(item);
        localStorage.setItem("cart",JSON.stringify(products));
    }else{
        products=JSON.parse(localStorage.getItem("cart"));
        products.push(item);
        localStorage.setItem("cart",JSON.stringify(products));

    }
    products=JSON.parse(localStorage.getItem("cart"));
    cart_n.innerHTML=`[${products.lenght}]`;
    document.getElementById(btncart).style.display="none";
    // animation();

}



function cart2(name,price,URL,con,btncart){
    var item={
        name:name,
        price:price,
        URL:URL
    }
    cartItems.push(item);
    let storage=JSON.parse(localStorage.getItem("cart"));
    if(storage==null){
        products.push(item);
        localStorage.setItem("cart",JSON.stringify(products));
    }else{
        products=JSON.parse(localStorage.getItem("cart"));
        products.push(item);
        localStorage.setItem("cart",JSON.stringify(products));

    }
    products=JSON.parse(localStorage.getItem("cart"));
    cart_n.innerHTML=`[${products.lenght}]`;
    document.getElementById(btncart).style.display="none";
    // animation();


}


// render

function render(){
    for(let index=1; index<=6; index++){
        fruitDIV.innerHTML+=`${HTMLfruitProduct(index)}`;
    }

    for(let index=1; index<=3; index++){
        juiceDIV.innerHTML+=`${HTMLjuiceProduct(index)}`;
        saladDIV.innerHTML+=`${HTMLsaladProduct(index)}`;
    }

    if(localStorage.getItem("cart")==null){

    }else{
        products=JSON.parse(localStorage.getItem("cart"));
        cart_n.innerHTML=`[${products.lenght}]`;
    }



}